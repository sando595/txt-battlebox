ZZZ CUSTOM ITEMS - Minecraft Java 1.21.11

Pliki 1-8 są podpięte jako Custom Model Data 1-8 na DIAMENTOWYM MIECZU.

Mapowanie:
1 (1).png -> CMD 1
2 (1).png -> CMD 2
3 (1).png -> CMD 3 (model korzysta z pozycji trzymania kuszy)
4 (1).png -> CMD 4
5 (1).png -> CMD 5
6 (1).png -> CMD 6
7 (1).png -> CMD 7
8 (1).png -> CMD 8

Modele 1, 2, 4, 5, 6, 7, 8 używają transformacji handheld (jak miecz).
Model 3 używa modelu bazowego crossbow (pozycja trzymania jak kusza).

Instalacja/test:
1. Wgraj zawartość ZIP-a jako resource pack albo rozpakuj folder do resourcepacks.
2. W grze włącz paczkę.
3. Testuj na diamentowym mieczu z komponentem custom_model_data:
   /give @s minecraft:diamond_sword[minecraft:custom_model_data={floats:[1.0]}]
   Zmień 1.0 na 2.0 ... 8.0, aby sprawdzić pozostałe tekstury.

UWAGA:
To jest paczka dla Minecraft Java 1.21.11 (format zasobów 75).
Wszystkie modele są przypisane do diamentowego miecza. Jeśli w skrypcie legendarki używasz
innego bazowego przedmiotu (np. kuszy), trzeba będzie przenieść mapowanie do jego pliku
assets/minecraft/items/<item>.json albo zmienić bazowy przedmiot w skrypcie.
